
curl --location --request POST 'http://0.0.0.0:5000/anuvaad/ocr/v0/ulca-ocr' \
--header 'Content-Type: application/csv' \
--data-raw '{
    "config": {
        "language": {
            "sourceLanguage": "en"
        }
    },
    "imageUri": ["https://tinyurl.com/wt87pwnn"]
    }
'
