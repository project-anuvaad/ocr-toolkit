

echo Testing a valid request
echo  
bash ./curl_valid_request.sh
echo
echo

echo Request with invalid image 
echo
bash ./curl_invalid_image.sh
echo
echo

echo Request with invalid language
echo
bash ./curl_invalid_lang.sh
echo
echo

echo Encoding HTML in request 
echo
bash ./curl_html_in_request.sh
echo
echo

echo Sending request with non JSON object
echo
bash ./curl_non_json_request.sh
echo
echo

echo Sending non POST request 
echo
bash ./curl_method_not_post.sh
echo
echo
