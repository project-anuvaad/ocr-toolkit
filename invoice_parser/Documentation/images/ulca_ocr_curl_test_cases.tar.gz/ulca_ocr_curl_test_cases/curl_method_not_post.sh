
curl --location --request PUT 'http://0.0.0.0:5000/anuvaad/ocr/v0/ulca-ocr' \
--header 'Content-Type: application/json' \
--data-raw '{
    "config": {
        "language": {
            "sourceLanguage": "en"
        }
    },
    "imageUri": ["https://tinyurl.com/wt87pwnn"]
    }
'
