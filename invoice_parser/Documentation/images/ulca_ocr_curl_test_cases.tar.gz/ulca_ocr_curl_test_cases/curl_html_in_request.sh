
curl --location --request POST 'http://0.0.0.0:5000/anuvaad/ocr/v0/ulca-ocr' \
--header 'Content-Type: application/json' \
--data-raw '{
    "config": {
        "dummy_key_1" : "<html> </html>",
        "language": {
            "sourceLanguage": "en <head>"
        }
    },
    "imageUri": ["https://tinyurl.com/wt87pwnn <body>"],
    "dummy_key_2" : "<title>"
    }
'
